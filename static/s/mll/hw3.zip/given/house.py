import numpy as np
from matplotlib import pyplot as plt
from sklearn.linear_model import Lasso
from sklearn.utils._testing import ignore_warnings
from sklearn.exceptions import ConvergenceWarning
from sklearn.preprocessing import StandardScaler

# https://lib.stat.cmu.edu/datasets/boston
PATH = 'BostonHousing.csv'
legends = [
    'crim', 'zn', 'indus', 'chas', 'nox', 'rm', 'age', 'dis', 'rad', 'tax',
    'ptratio', 'b', 'lstat', 'medv'
]  # Charles River dummy variable (= 1 if tract bounds river; 0 otherwise)
Xy = np.genfromtxt(PATH,
                   delimiter=',',
                   skip_header=1,
                   encoding='UTF-8',
                   dtype=None,
                   converters={
                       3: lambda s: float(s[1:-1]),
                       8: lambda s: float(s),
                       9: lambda s: float(s)
                   })
legends.remove(legends[-1])  # remove prediction value legend
X, y = Xy[:, :-1], Xy[:, -1]
X = StandardScaler().fit_transform(X)
# we don't stack column of ones, why?
# https://stackoverflow.com/a/12578769/12035739
