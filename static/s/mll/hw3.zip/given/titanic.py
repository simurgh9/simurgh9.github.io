import numpy as np
from matplotlib import pyplot as plt
from sklearn.impute import SimpleImputer
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.preprocessing import FunctionTransformer
from sklearn.pipeline import Pipeline
from sklearn.linear_model import Lasso


# 0       1         2     3    4    5      6
# pclass  survived  name  sex  age  sibsp  parch
# 7       8     9      10        11    12    13
# ticket  fare  cabin  embarked  boat  body  home.dest  


data = np.loadtxt('../../hw1/code/titanic.csv', delimiter=',', dtype=object)
features = data[0]
data = data[1:]
y = data[:, 1].astype(np.float64)



transformers=[
    ('boat_body', Pipeline([
        ('exists', FunctionTransformer(lambda x: np.int64(x == ''))),
    ]), [11, 12]),
    ('categorical', Pipeline([
        ('to_nan', FunctionTransformer(lambda x: np.where(x == '', np.nan, x))),
        ('impute', SimpleImputer(strategy='most_frequent')),
        ('encode', OneHotEncoder(handle_unknown='ignore'))
    ]), [0, 3, 10]),
    ('numerical', Pipeline([
        ('to_nan', FunctionTransformer(lambda x: np.where(x == '', np.nan, x))),
        ('impute', SimpleImputer(strategy='median')),
        ('scaler', StandardScaler())
    ]), [4, 5, 6, 8])
]

preprocessor = ColumnTransformer(transformers)
X_transformed = preprocessor.fit_transform(data)
features_transformed = [
    'boat', 'body', 'pclass_1', 'pclass_2', 'pclass_3', 'sex_female', 'sex_male',
    'embarked_C', 'embarked_Q', 'embarked_S', 'age', 'sibsp', 'parch', 'fare'
]
