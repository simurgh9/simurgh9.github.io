from model import Model

class Control:
    def __init__(self, view):
        self.M = Model()
        self.V = view

    def new_model(self, event):
        self.M = Model()
        self.V.repaint()

    def handle_click(self, event):
        dx = self.V.W // self.M.N
        dy = self.V.H // self.M.N

        j = event.x // dx
        i = event.y // dy
        self.M.update_state(i, j)
        self.V.repaint()
