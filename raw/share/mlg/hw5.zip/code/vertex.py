class Vertex:
    MIN = -1
    MAX = 1
    FREE = 0
    CONT = 2

    def __init__(self, board):
        self.board = board
        self.children = []
        self.utility = self.CONT

    def copy(self):
        return [row[:] for row in self.board]

    def minimax(self, turn):
        if (turn == self.MAX):
            self.utility = max([child.utility for child in self.children])
        else:
            self.utility = min([child.utility for child in self.children])
        return self.utility

    def terminal(self):
        transpose = [list(row) for row in zip(*self.board)]
        for each in [self.board, transpose]:
            result = self.rows(each)
            if result != self.CONT:
                return result
        result = self.diagonals(self.board)
        if result != self.CONT:
            return result
        if not any(self.FREE in row for row in self.board):
            return self.FREE  # game's a draw
        return self.CONT

    def rows(self, board):
        for row in board:
            if row[0] != self.FREE and len(set(row)) == 1:
                return row[0]
        return self.CONT

    def diagonals(self, board):
        diagonal = [board[i][i] for i in range(len(board))]
        if diagonal[0] != self.FREE and len(set(diagonal)) == 1:
            return diagonal[0]
        anti = [board[i][len(board) - i - 1] for i in range(len(board))]
        if anti[0] !=  self.FREE and len(set(anti)) == 1:
            return anti[0]
        return self.CONT
