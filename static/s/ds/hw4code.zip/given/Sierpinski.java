public class Sierpinski {
  public static void main(String[] args) {
    new Canvas(new Sierpinski());
  }

  public void points(int x, int y, int w, int h, Queue<Coordinates> q, int r) {
    // implement me
  }
}