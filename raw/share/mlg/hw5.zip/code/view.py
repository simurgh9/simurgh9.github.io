from tkinter import Tk, Frame, Canvas, ALL
from math import log, floor  # for frame dims
from vertex import Vertex
from control import Control

class View(Frame):
    def __init__(self, master):
        super().__init__(master)
        self.MASTER, self.C = master, Control(self)
        self.W, self.H = self.init_screen_dims(smaller=True)
        self.MASTER.title(self.C.M.message)
        self.MASTER.geometry('%dx%d+%d+%d' % (self.W, self.H, 0, 0))
        self.MASTER.bind('<Button 1>', self.C.handle_click)
        self.MASTER.bind('<Button 2>', self.C.new_model)
        self.pack(fill='both', expand=True)
        self.can = Canvas(self)
        self.can.pack()
        self.repaint()

    def repaint(self, event=None):
        self.can.delete(ALL)
        self.draw_grid()
        plays = self.C.M.get_state()
        for i, row in enumerate(plays):
            for j, play in enumerate(row):
                if play == Vertex.FREE:
                    continue
                self.draw_play(i, j, play)
        self.MASTER.title(self.C.M.message)

    def draw_play(self, i, j, turn):
        dx = self.W // self.C.M.N
        dy = self.H // self.C.M.N
        x, y = j * dx, i * dy
        ot = int(0.2 * dx)
        if turn == Vertex.MIN:
            self.can.create_oval(x + ot,
                                 y + ot,
                                 x + dx - ot,
                                 y + dy - ot,
                                 width=5,
                                 outline='white')
        else:
            self.can.create_line(x + ot,
                                 y + ot,
                                 x + dx - ot,
                                 y + dy - ot,
                                 fill='green',
                                 width=5)
            self.can.create_line(x + dx - ot,
                                 y + ot,
                                 x + ot,
                                 y + dy - ot,
                                 fill='green',
                                 width=5)

    def draw_grid(self):
        dx = self.W // self.C.M.N
        dy = self.H // self.C.M.N

        x = dx
        while x < self.W - dx:
            self.can.create_line(x, 0, x, self.H, fill='grey', width=2)
            x += dx

        y = dy
        while y < self.H - dy:
            self.can.create_line(0, y, self.W, y, fill='grey', width=2)
            y += dy

    def init_screen_dims(self, smaller=False):
        # the bias is the border width
        W = 2**floor(log(self.MASTER.winfo_screenwidth() // 2, 2)) + 2
        H = 2**floor(log(self.MASTER.winfo_screenheight() // 2, 2)) + 2
        if smaller:
            return min(W, H), min(W, H)
        return W, H

if __name__ == '__main__':
    root = Tk()
    root.tk.call('tk', 'scaling', 6.0)  # may need to comment
    view = View(root)
    view.mainloop()
