/**
 * Name: Tashfeen, Ahmad
 * File: CaesarCipher.java
 * Description: Caesar cipher.
 */

public class CaesarCipher {
    private int key;
    private String shiftedText;
    private String plainText;

    public CaesarCipher(String plainText, int key) {
        this.key = key;
        this.plainText = plainText;
        this.shiftedText = this.shift();
    }

    public String toString() {
        /* [Implement Me] When the object CaesarCipher is passed to the 
         * System.out.println(...) the string returned from this function
         * is printed.
         */
    } 

    private String shift() {
        /* [Implement Me] This function should  return the shifted
         * version of the this.plainText. Write a for-loop that 
         * iterates over the characters of the this.plainText and checks
         * if each is one of the 26 letters in the English alphabet using
         *  this.isLetter(...) and if so then shifts using this.key.
         */
    }

    private boolean isLetter(String letter) {
        /* Returns true if the letter is one of the 26 letters in
         * the English alphabet. False otherwise.
         */
    }

    private int mathMod(int x, int n) {
        // always returns a positive mod
        return ((x % n) + n) % n;
    }
}