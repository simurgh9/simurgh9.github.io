from vertex import Vertex


class Model:

    def __init__(self):
        self.N = 3
        self.message = 'Tic Tac Toe'
        board = [[Vertex.FREE for _ in range(self.N)] for _ in range(self.N)]
        self.root = Vertex(board)
        self.grow(self.root, Vertex.MAX, 0)

    def grow(self, root, turn, utility):
        """
        Recursively grow the Tic Tac Toe Minimax tree. You need to use the
        root.terminal() in combination with root.minimax(turn).
        """
        pass

    def get_state(self):
        return self.root.board

    def update_state(self, i, j):
        root = self.new_root(i, j)
        if (root is None):
            return
        self.root = root
        child = self.mini()
        self.root = child
        self.message = self.eval_message()

    def mini(self):
        """
        Since we play as the max player. This function returns the min child
        of the current self.root.
        """
        pass

    def new_root(self, i, j):
        move = self.root.copy()
        move[i][j] = Vertex.MAX  # because we play as max
        for child in self.root.children:
            if child.board == move:
                return child
        return None

    def eval_message(self):
        if len(self.root.children) > 0:
            return self.message;
        elif self.root.terminal() == 0:
            return "Draw! (right click to reset)."
        else:
            return "Peasant! (right click to reset)."

if __name__ == '__main__':
    x = Model()

    def dfs(root, leaves, player):
        """
        Implement depth first search to count the leaves for where min/-1,
        max/1 or draw/0, i. e., "player" occurs.
        """
        pass

    a = dfs(x.root, 0, 1)  # 131184
    b = dfs(x.root, 0, -1)  # 77904
    c = dfs(x.root, 0, 0)  # 46080
    print(a == 131184, b == 77904, c == 46080)
