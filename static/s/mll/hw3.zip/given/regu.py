import numpy as np
from matplotlib import pyplot as plt
from sklearn.linear_model import Ridge


n = 7
X = 1 / (np.arange(1, n + 1) + np.arange(0, n).reshape(-1, 1))  # n by n
y = np.ones(n)
alphas = np.logspace(-10, -2)
